@extends('layouts.base')

@section('title')Estado envío @endsection


@section('contenido')
<h2 align="center">Estado envío</h2>
<br>

 <div class="row">
    <div class="col">
        <div id="tabla_confirmacionmail"  style="padding-left: 40px;">
        <table id="confirmacion_email" name="confirmacion_email">
          <tr><td><b>De: </b></td><td>&nbsp;&nbsp;</td><td>{{$email}}</td></tr>
          <tr><td><b>Asunto: </b></td><td>&nbsp;&nbsp;</td><td>{{$asunto}}</td></tr>
          <tr><td><b>Mensaje: </b></td><td>&nbsp;&nbsp;</td><td>{{$contenido}}</td></tr>
        </table>
       </div>
      
    </div>
  </div> 
  <br><br><br>

 
 
   <a class="btn btn-primary" href="/">Inicio</a>
@endsection