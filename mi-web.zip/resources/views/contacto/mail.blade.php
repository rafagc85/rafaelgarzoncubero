<div class="row">
	<div class="col">
		<h2>Mensaje de </h2>

	</div>
</div>

<div class="row">
	<div class="col">
		<h5>Asunto: {{$asunto}}</h2>
		<p>Mensaje: {{$contenido}}</p>
	</div>
</div>
