@extends('layouts.base')

@section('title')
Currículum Vitae
@endsection
