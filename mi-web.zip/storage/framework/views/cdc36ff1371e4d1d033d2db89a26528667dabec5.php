<?php $__env->startSection('title'); ?> Contacto <?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<h2 align="center">Contacto</h2>

	<div class="row">
    <div class="col">
    	
    	<form action="/contacto/confirmSendMail" method="POST">
            <?php echo csrf_field(); ?> 
    		<div class="form-group">
    			<br>
    			<input type="text" class="form-control" id="email" name="email" placeholder="email">

    			<br>
    			<input type="text" class="form-control" id="asunto" name="asunto" placeholder="asunto">
    			<br>
    			<textarea rows="4" cols="50" class="form-control" id="contenido" name="contenido" >
    				contenido
    			</textarea>

    		</div>
    		<button class="btn btn-primary" type="submit">Vista Previa</button>
    	</form>

    </div>
  </div> 
   <a class="btn btn-secondary" href="/">Atras</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\mi-web\resources\views/contacto/formulario.blade.php ENDPATH**/ ?>