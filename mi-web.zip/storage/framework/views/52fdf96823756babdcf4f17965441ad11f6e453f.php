<?php $__env->startSection('title'); ?>Currículum Vitae <?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>
<h1 align="center">Currículum Vitae</h1>
<br>

 <div class="row">
    <div class="col">
        <?php $__currentLoopData = $eventos_tipo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipos_evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3><?php echo e($tipos_evento->nombre_tipo_evento); ?></h3>

             <table border="0">

             <?php $__currentLoopData = $eventos_por_tipoEvento[$tipos_evento->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento_por_tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                 <tr><td><div id="titulo" name="titulo" style="padding-left: 20px; color: 282828; font-size: 25px;"><?php echo e($evento_por_tipo->nombre); ?></div>

                <div id="descripcion" name="descripcion" style="padding-left: 30px; color: 282828; font-size: 17px;">  
                 <?php if($organismo_id[$evento_por_tipo->id_organismo]->isNotEmpty()): ?>
                     <?php $__currentLoopData = $organismo_id[$evento_por_tipo->id_organismo]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el_organismo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($el_organismo->nombre_organismo); ?>.

                           <?php if(isset($el_organismo->descripcion)): ?>
                                 <?php echo e($el_organismo->descripcion); ?>

                           <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php endif; ?>  
                 
   


                 <?php if(isset($evento_por_tipo->fecha)): ?>  
                     Año&nbsp;<?php echo date("Y",strtotime("$evento_por_tipo->fecha")); ?>
                 <?php else: ?>
                    
                 <?php endif; ?>


                 <?php if(isset($evento_por_tipo->descripcion_corta)): ?>
                   <br>
                    <?php echo e($evento_por_tipo->descripcion_corta); ?>.

                 <?php endif; ?>


                 <?php if($tecnologias[$evento_por_tipo->id]->isNotEmpty()): ?>
                  Tecnologías: <b>
                    <?php // var_dump($tecnologias[$evento_por_tipo->id]); ?>
                    <?php $__currentLoopData = $tecnologias[$evento_por_tipo->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tecnologia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php if(isset($tecnologia)): ?>
                             
                             <?php $__currentLoopData = $tecnologia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $una_tecnologia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo e($una_tecnologia->nombre_tecnologia); ?>

                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </b>
                 <?php endif; ?>
                 

                
                
             
                  </div>
                 </td></tr>
                 <tr><td><br></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
          <br>
      
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br>

      


       
 
    </div>
  </div> 
   <a class="btn btn-primary" href="/curriculum/create">Nuevo evento</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\mi-web\resources\views/curriculum/index.blade.php ENDPATH**/ ?>