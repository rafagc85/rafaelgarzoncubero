<?php $__env->startSection('title'); ?><?php echo e($ver_evento->nombre); ?> <?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>
<h1>Curriculum</h1>
 <div class="row">
    <div class="col">


     <h3><?php echo e($ver_evento->nombre); ?></h3>
     	<table class="table">
            <tr>
               
                <?php $__currentLoopData = $tecnologias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tecnologia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               
                       <td> Tecnología: <?php echo e($tecnologia->tecnologia); ?>  </td>
   
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </tr>	
        </table>  
    </div>
  </div> 
   <a class="btn btn-secondary" href="/curriculum">Atras</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\mi-web\resources\views/curriculum/show.blade.php ENDPATH**/ ?>