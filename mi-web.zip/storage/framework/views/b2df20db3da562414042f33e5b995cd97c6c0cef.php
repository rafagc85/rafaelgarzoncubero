<div class="row">
	<div class="col">
		<h2>Mensaje de </h2>

	</div>
</div>

<div class="row">
	<div class="col">
		<h5>Asunto: <?php echo e($asunto); ?></h2>
		<p>Mensaje: <?php echo e($contenido); ?></p>
	</div>
</div>
<?php /**PATH C:\xampp\mi-web\resources\views/contacto/mail.blade.php ENDPATH**/ ?>