<?php $__env->startSection('title'); ?>Eliminar un evento <?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>
<h1>Eliminar evento: <?php echo e($eliminar_evento->id); ?></h1>
 <div class="row">
    <div class="col">
    	
    	<form action="/curriculum/<?php echo e($eliminar_evento->id); ?>" method="POST">
            <?php echo csrf_field(); ?> 
            <?php echo method_field('delete'); ?>
    		
    		<button class="btn btn-primary" type="submit">Eliminar</button>
    	</form>

    </div>
  </div> 
   <a class="btn btn-secondary" href="/curriculum">Atras</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\mi-web\resources\views/curriculum/confirmDelete.blade.php ENDPATH**/ ?>