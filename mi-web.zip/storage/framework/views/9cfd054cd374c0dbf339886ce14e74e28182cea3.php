<?php $__env->startSection('title'); ?>Agregar nuevo evento al Curriculum <?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>
<h1>Nuevo evento</h1>

<?php if($errors->any()): ?>
 <div class="row">
    <div class="col">
    	<div class="alert alert-danger">
	    	<ul>
	    		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    		<li><?php echo e($error); ?></li>
	    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    	</ul>
    </div>
    </div>
</div>
<?php endif; ?>

<br>

 <div class="row">
    <div class="col">
    	
    	<form action="/curriculum" method="POST">
            <?php echo csrf_field(); ?> 
    		<div class="form-group">
    			<div class="form-row">
			      <div class="col">
						<select name="tipo_evento" class="btn btn-secondary dropdown-toggle" >
						<option value="0">- Tipo de evento -</option>
						<?php $__currentLoopData = $tipos_eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							 <option value="<?php echo e($tipo_evento->id); ?>"><?php echo e($tipo_evento->nombre_tipo_evento); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </select>
			     </div>
			     <div class="col">
			     	   <select name="id_organismo" class="btn btn-secondary dropdown-toggle" >
					   <option value="0">- Organismo -</option>
					   <?php $__currentLoopData = $organismos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organismo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						 <option value="<?php echo e($organismo->id_organismo); ?>"><?php echo e($organismo->nombre_organismo); ?></option>
					   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				       </select>
			     </div>
			   </div>

				<br><br>

    			<label for="nombre">Nombre del evento:</label>
    			<input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre del evento" value="<?php echo e(old('nombre')); ?>">

    			<br>

    			<label for="descripcion_corta">Descripción corta:</label>
    			<textarea rows="4" cols="50" class="form-control" id="descripcion_corta" name="descripcion_corta" >
    				Descripción corta del evento
    			</textarea>

    			<br>

    			<label for="descripcion_larga">Descripción larga:</label>
    			<textarea rows="4" cols="50" class="form-control" id="descripcion_larga" name="descripcion_larga" >
    				Descripción larga del evento
    			</textarea>

    			<br>

    			<div class="form-row">
			    <div class="col">
			     	<input type="text" class="form-control" id="horas" name="horas"  placeholder="Horas" value="<?php echo e(old('horas')); ?>">
			    </div>
			    <div class="col">
			    	<input type="text" class="form-control" id="calificacion" name="calificacion" placeholder="Calificación" value="<?php echo e(old('calificacion')); ?>">
			    </div>
			    <div class="col">
			      	<input type="date" class="form-control" id="fecha" name="fecha" placeholder="Fecha" value="<?php echo e(old('fecha')); ?>">
			    </div>
			  </div>

    		</div>
    		<button class="btn btn-primary" type="submit">Guardar</button><a class="btn btn-secondary" href="/curriculum">Atras</a>
    	</form>

    </div>
  </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\mi-web\resources\views/curriculum/create.blade.php ENDPATH**/ ?>