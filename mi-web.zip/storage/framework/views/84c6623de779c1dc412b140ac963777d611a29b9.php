<?php $__env->startSection('title'); ?>Confirmar envío de mensaje <?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>
<h2 align="center">Confirmar envío de mensaje</h2>
<br>

 <div class="row">
    <div class="col">
      <div id="tabla_confirmacionmail"  style="padding-left: 40px;">
        <table id="confirmacion_email" name="confirmacion_email">
          <tr><td><b>De: </b></td><td>&nbsp;&nbsp;</td><td><?php echo e($email); ?></td></tr>
          <tr><td><b>Asunto: </b></td><td>&nbsp;&nbsp;</td><td><?php echo e($asunto); ?></td></tr>
          <tr><td><b>Mensaje: </b></td><td>&nbsp;&nbsp;</td><td><?php echo e($contenido); ?></td></tr>
        </table>
       </div>
      
    </div>
  </div> 
  <br><br><br>

   <form action="/contacto/SendMail" method="POST">
      <?php echo csrf_field(); ?> 
   <div class="form-group">
    <br>
    <input type="hidden" class="form-control" id="email" name="email" value="<?php echo e($email); ?>">

    <br>
    <input type="hidden" class="form-control" id="asunto" name="asunto" value="<?php echo e($asunto); ?>" >

    <br>
   <input type="hidden" class="form-control" id="contenido" name="contenido" value="<?php echo e($contenido); ?>">

 </div>
  <button class="btn btn-primary" type="submit">Enviar</button>
 </form>
 
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\mi-web\resources\views/contacto/confirmacion.blade.php ENDPATH**/ ?>