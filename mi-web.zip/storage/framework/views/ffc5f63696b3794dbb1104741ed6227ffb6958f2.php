<?php $__env->startSection('title'); ?>Agregar nuevo evento al Curriculum <?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>
<h1>Editar evento <?php echo e($editar_evento->id); ?></h1>
 <div class="row">
    <div class="col">
    	
    	<form action="/curriculum/<?php echo e($editar_evento->id); ?>" method="POST">
            <?php echo csrf_field(); ?> 
            <?php echo method_field('put'); ?>
    		<div class="form-group">
    			<label for="Tipo_evento">Tipo de evento:</label>
    			<input type="text" class="form-control" id="id_tipo_evento" name="id_tipo_evento" placeholder="id del tipo de evento">

    			<label for="nombre">Nombre del evento:</label>
    			<input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre del evento">

    			<label for="descripcion_corta">Descripción del evento:</label>
    			<textarea rows="4" cols="50" class="form-control" id="descripcion_corta" name="descripcion_corta" >
    				Descripción corta del evento
    			</textarea>

    		</div>
    		<button class="btn btn-primary" type="submit">Guardar</button>
    	</form>

    </div>
  </div> 
   <a class="btn btn-secondary" href="/curriculum">Atras</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\mi-web\resources\views/curriculum/edit.blade.php ENDPATH**/ ?>