<?php $__env->startSection('title'); ?>Estado envío <?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>
<h2 align="center">Estado envío</h2>
<br>

 <div class="row">
    <div class="col">
        <div id="tabla_confirmacionmail"  style="padding-left: 40px;">
        <table id="confirmacion_email" name="confirmacion_email">
          <tr><td><b>De: </b></td><td>&nbsp;&nbsp;</td><td><?php echo e($email); ?></td></tr>
          <tr><td><b>Asunto: </b></td><td>&nbsp;&nbsp;</td><td><?php echo e($asunto); ?></td></tr>
          <tr><td><b>Mensaje: </b></td><td>&nbsp;&nbsp;</td><td><?php echo e($contenido); ?></td></tr>
        </table>
       </div>
      
    </div>
  </div> 
  <br><br><br>

 
 
   <a class="btn btn-primary" href="/">Inicio</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\mi-web\resources\views/contacto/estadoEnvio.blade.php ENDPATH**/ ?>