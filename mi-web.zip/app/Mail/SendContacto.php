<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class SendContacto extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */

    private $asunto;
    private $contemido;

    public function __construct($asunto, $contenido)
    {
       $this->asunto = $asunto;
       $this->contenido = $contenido;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('contacto.mail',[
            'asunto'=> $this->asunto,
            'contenido'=>$this->contenido
        ]);
    }
}
